package com.espressif.ui;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;

import com.espressif.wifi_provisioning.R;

public class CustomDataDialog extends Dialog {

    private EditText editTextCustomData;
    private Button btnSubmit;
    private CustomDataListener listener;

    public interface CustomDataListener {
        void onDataSubmitted(String data);
    }

    public CustomDataDialog(@NonNull Context context, CustomDataListener listener) {
        super(context);
        this.listener = listener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.espressif.wifi_provisioning.R.layout.dialog_custom_data);

        editTextCustomData = findViewById(R.id.editTextCustomData);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data = editTextCustomData.getText().toString();
                if (!data.isEmpty() && listener != null) {
                    listener.onDataSubmitted(data);
                    dismiss();
                }
            }
        });
    }
} 